import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-4BNLCFN7.js";
import "./chunk-3YLIHGSD.js";
import "./chunk-TQM5CU5Z.js";
import "./chunk-HU3CBU3B.js";
import "./chunk-IU6HWN4Q.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-GOMI4DH3.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
