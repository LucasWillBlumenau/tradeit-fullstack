import { Component } from "@angular/core";

@Component({
    selector: "app-modal-form-wrapper",
    imports: [],
    templateUrl: "./modal-form-wrapper.html",
    styleUrl: "./modal-form-wrapper.css",
})
export class ModalFormWrapper {}
