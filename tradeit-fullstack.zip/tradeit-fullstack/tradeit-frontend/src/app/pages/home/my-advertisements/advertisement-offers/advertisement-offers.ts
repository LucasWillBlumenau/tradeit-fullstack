import { Component, inject, input, OnInit, signal } from "@angular/core";
import { OfferDetails } from "../../../../model/offer/offer-details";
import { AdvertisementService } from "../../../../services/advertisement-service";

@Component({
    selector: "app-advertisement-offers",
    imports: [],
    templateUrl: "./advertisement-offers.html",
    styleUrl: "./advertisement-offers.css",
})
export class AdvertisementOffers implements OnInit {
    private readonly advertisementService = inject(AdvertisementService);

    public readonly advertisementId = input.required<number>();
    protected readonly offers = signal<OfferDetails[] | null>(null);

    ngOnInit(): void {
        this.advertisementService.getOffersFromAdvertisement(this.advertisementId()).subscribe({
            next: (offers) => console.log(offers),
        });
    }
}
