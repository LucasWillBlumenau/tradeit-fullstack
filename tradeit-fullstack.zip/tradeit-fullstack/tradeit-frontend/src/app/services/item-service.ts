import { inject, Injectable } from "@angular/core";
import { environment } from "../../environments/environment";
import { Observable } from "rxjs";
import { ItemPage } from "../model/item/item-page";
import { HttpClient } from "@angular/common/http";

@Injectable({
    providedIn: "root",
})
export class ItemService {
    private readonly apiUrl = environment.apiUrl;
    private readonly httpClient = inject(HttpClient);

    getItemsFromPage(pageNumber: number): Observable<ItemPage> {
        const url = `${this.apiUrl}/api/v1/items`;
        return this.httpClient.get<ItemPage>(url, {
            params: {
                page: pageNumber,
            },
            withCredentials: true,
        });
    }
}
