export interface OfferCreation {
    itemCondition: string;
    additionalMoneyOffer: string;
    description: string;
    images: FileList;
    video: File;
}
