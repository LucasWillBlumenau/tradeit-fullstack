ALTER TABLE advertisements ADD COLUMN item_condition VARCHAR(6) NOT NULL;

ALTER TABLE offers ADD COLUMN item_condition VARCHAR(6) NOT NULL;
