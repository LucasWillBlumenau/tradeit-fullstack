package br.com.senior.tradeit.entity.offer;

public enum OfferStatus {
    PENDING,
    ACCEPTED,
    DENIED,
    CANCELLED,
}
