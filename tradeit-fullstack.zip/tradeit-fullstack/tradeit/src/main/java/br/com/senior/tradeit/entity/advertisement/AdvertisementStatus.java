package br.com.senior.tradeit.entity.advertisement;

public enum AdvertisementStatus {
    ACTIVE,
    CLOSED,
    CANCELLED,
}
