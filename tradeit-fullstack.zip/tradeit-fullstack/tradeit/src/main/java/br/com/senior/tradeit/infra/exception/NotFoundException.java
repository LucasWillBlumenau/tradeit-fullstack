package br.com.senior.tradeit.infra.exception;

public class NotFoundException extends RuntimeException {

    public NotFoundException() {
        super();
    }
}
