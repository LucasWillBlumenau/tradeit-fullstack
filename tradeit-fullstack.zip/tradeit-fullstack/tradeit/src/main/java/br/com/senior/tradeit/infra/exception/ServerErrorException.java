package br.com.senior.tradeit.infra.exception;

public class ServerErrorException extends RuntimeException {
}
