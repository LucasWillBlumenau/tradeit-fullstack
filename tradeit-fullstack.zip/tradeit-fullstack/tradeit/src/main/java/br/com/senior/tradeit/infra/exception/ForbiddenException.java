package br.com.senior.tradeit.infra.exception;

public class ForbiddenException extends RuntimeException {
}
