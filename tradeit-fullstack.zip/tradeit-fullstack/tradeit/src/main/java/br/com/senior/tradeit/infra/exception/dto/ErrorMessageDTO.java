package br.com.senior.tradeit.infra.exception.dto;

public record ErrorMessageDTO(
        String message
) {
}
