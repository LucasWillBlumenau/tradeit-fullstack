package br.com.senior.tradeit.dto.user;

public record JWTToken(
        String tokenValue
) {
}
