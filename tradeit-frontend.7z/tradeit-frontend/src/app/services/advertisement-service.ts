import { HttpClient } from "@angular/common/http";
import { Injectable, inject } from "@angular/core";
import { Observable } from "rxjs";
import { AdvertisementsPage } from "../model/advertisement/advertisement-page";
import { environment } from "../../environments/environment";
import { AdvertisementDetails } from "../model/advertisement/advertisement-details";
import { Advertisement } from "../model/advertisement/advertisement";

@Injectable({
    providedIn: "root",
})
export class AdvertisementService {
    private readonly httpClient = inject(HttpClient);
    private readonly apiUrl = environment.apiUrl;

    getAdvertisements(): Observable<AdvertisementsPage> {
        return this.httpClient.get<AdvertisementsPage>(`${this.apiUrl}/api/v1/advertisements`, {
            withCredentials: true,
        });
    }

    getUserAdvertisements(): Observable<Advertisement[]> {
        return this.httpClient.get<Advertisement[]>(`${this.apiUrl}/api/v1/advertisements/mine`, {
            withCredentials: true,
        });
    }

    getAdvertisementById(id: number): Observable<AdvertisementDetails> {
        return this.httpClient.get<AdvertisementDetails>(`${this.apiUrl}/api/v1/advertisements/${id}`, {
            withCredentials: true,
        });
    }
}
