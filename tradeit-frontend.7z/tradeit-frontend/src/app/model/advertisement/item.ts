export interface Item {
    id: number;
    name: string;
    categoryId: number;
}
