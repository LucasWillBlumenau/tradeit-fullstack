import { Item } from "./item";

export interface Advertisement {
    id: number;
    description: string;
    item: Item;
    tradingItem: Item;
    extraMoneyAmountRequired: number;
    imageUrl: string;
    condition: string;
}
