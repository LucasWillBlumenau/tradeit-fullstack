export interface OfferCreation {
    itemCondition: string;
    additionalMoneyOffer: string;
    images: FileList;
    video: File;
}
