import { Component } from '@angular/core';

@Component({
  selector: 'app-field-set',
  imports: [],
  templateUrl: './field-set.html',
  styleUrl: './field-set.css',
})
export class FieldSet {

}
