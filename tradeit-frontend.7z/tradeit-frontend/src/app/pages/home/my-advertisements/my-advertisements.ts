import { Component, inject, OnInit, signal } from "@angular/core";
import { AdvertisementInfo } from "./advertisement-info/advertisement-info";
import { AdvertisementService } from "../../../services/advertisement-service";
import { Advertisement } from "../../../model/advertisement/advertisement";

@Component({
    selector: "app-my-advertisements",
    imports: [AdvertisementInfo],
    templateUrl: "./my-advertisements.html",
    styleUrl: "./my-advertisements.css",
})
export class MyAdvertisements implements OnInit {
    private readonly advertisementService = inject(AdvertisementService);

    protected advertisements = signal<Advertisement[] | null>(null);

    ngOnInit(): void {
        this.advertisementService.getUserAdvertisements().subscribe({
            next: (advertisements) => {
                this.advertisements.set(advertisements);
                console.log(advertisements);
            },
        });
    }
}
