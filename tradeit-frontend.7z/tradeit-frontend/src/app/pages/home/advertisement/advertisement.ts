import { Component, inject, OnInit, signal } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { AdvertisementService } from "../../../services/advertisement-service";
import { AdvertisementDetails } from "../../../model/advertisement/advertisement-details";
import { Slide } from "./slide/slide";
import { Resource, ResourceType } from "../../../model/resource/resource";
import { environment } from "../../../../environments/environment";
import { TranslateItemConditionPipe } from "../../../core/pipes/translate-item-condition-pipe";
import { CurrencyPipe } from "@angular/common";
import { Modal } from "../../shared/modal/modal";
import { CreateOfferForm } from "./create-offer-form/create-offer-form";

@Component({
    selector: "app-advertisement",
    imports: [Slide, TranslateItemConditionPipe, CurrencyPipe, Modal, CreateOfferForm],
    templateUrl: "./advertisement.html",
    styleUrl: "./advertisement.css",
})
export class Advertisement implements OnInit {
    private readonly activatedRoute = inject(ActivatedRoute);
    private readonly advertisementService = inject(AdvertisementService);
    private readonly apiUrl = environment.apiUrl;

    protected readonly advertisement = signal<AdvertisementDetails | null>(null);
    protected resources = signal<Resource[]>([]);

    ngOnInit(): void {
        const id = Number.parseInt(this.activatedRoute.snapshot.paramMap.get("id") as string);
        this.advertisementService.getAdvertisementById(id).subscribe({
            next: (advertisement) => this.setAdvertisement(advertisement),
        });
        return undefined;
    }

    setAdvertisement(advertisement: AdvertisementDetails): void {
        this.advertisement.set(advertisement);
        const imagesResources = advertisement.imageUrls.map((imageUrl) => ({
            type: "image" as ResourceType,
            url: `${this.apiUrl}${imageUrl}`,
        }));
        const videoResource = { type: "video" as ResourceType, url: `${this.apiUrl}${advertisement.videoUrl}` };
        this.resources.set([...imagesResources, videoResource]);
    }
}
