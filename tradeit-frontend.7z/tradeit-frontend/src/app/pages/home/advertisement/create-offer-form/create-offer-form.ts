import { Component, ElementRef, inject, input, output, ViewChild } from "@angular/core";
import { AdvertisementDetails } from "../../../../model/advertisement/advertisement-details";
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from "@angular/forms";
import { OfferCreation } from "../../../../model/offer/offer-creation";

@Component({
    selector: "app-create-offer-form",
    imports: [ReactiveFormsModule],
    templateUrl: "./create-offer-form.html",
    styleUrl: "./create-offer-form.css",
})
export class CreateOfferForm {
    public readonly advertisement = input.required<AdvertisementDetails>();
    public readonly submittion = output<OfferCreation>();

    protected formGroup: FormGroup;

    @ViewChild("imagesInput")
    private imagesFileInput!: ElementRef;
    @ViewChild("videoInput")
    private videoFileInput!: ElementRef;

    constructor() {
        const formBuilder = inject(FormBuilder);
        this.formGroup = formBuilder.group({
            condition: ["", Validators.required],
            extraMoneyOffer: ["", Validators.required],
            images: [null, Validators.required],
            video: [null, Validators.required],
        });
    }

    onImagesSelected(): void {
        this.formGroup.get("images")?.setValue(this.imagesFileInput.nativeElement.files);
    }

    onVideoSelected() {
        const files = this.videoFileInput.nativeElement.files;
        if (files.length > 0) {
            this.formGroup.get("video")?.setValue(files[0]);
        }
    }

    submitOffer(): void {
        const itemCondition = this.formGroup.get("condition")?.value as string;
        const additionalMoneyOffer = this.formGroup.get("additionalMoneyOffer")?.value as string;
        const images = this.formGroup.get("images")?.value as FileList;
        const video = this.formGroup.get("video")?.value as File;

        const offerCreation: OfferCreation = { itemCondition, additionalMoneyOffer, images, video };
        this.submittion.emit(offerCreation);
    }
}
