import { Component } from '@angular/core';

@Component({
  selector: 'app-my-offers',
  imports: [],
  templateUrl: './my-offers.html',
  styleUrl: './my-offers.css',
})
export class MyOffers {

}
