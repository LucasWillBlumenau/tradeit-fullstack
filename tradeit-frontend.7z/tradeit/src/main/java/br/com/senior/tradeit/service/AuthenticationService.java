package br.com.senior.tradeit.service;

import br.com.senior.tradeit.dto.user.JWTToken;
import br.com.senior.tradeit.dto.user.UserLoginDTO;
import br.com.senior.tradeit.infra.security.JWTTokenManager;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationService {

    private final AuthenticationManager authenticationManager;
    private final JWTTokenManager jwtTokenManager;

    public AuthenticationService(AuthenticationManager authenticationManager, JWTTokenManager jwtTokenManager) {
        this.authenticationManager = authenticationManager;
        this.jwtTokenManager = jwtTokenManager;
    }

    public JWTToken authenticateUser(UserLoginDTO userLogin) {
        var authenticationToken = new UsernamePasswordAuthenticationToken(
                userLogin.email(),
                userLogin.password()
        );
        authenticationManager.authenticate(authenticationToken);
        String token = jwtTokenManager.createToken(userLogin.email());
        return new JWTToken(token);
    }
}
