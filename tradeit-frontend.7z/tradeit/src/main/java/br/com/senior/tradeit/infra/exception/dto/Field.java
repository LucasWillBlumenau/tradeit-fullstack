package br.com.senior.tradeit.infra.exception.dto;


public record Field(
        String name,
        String message
) {}
