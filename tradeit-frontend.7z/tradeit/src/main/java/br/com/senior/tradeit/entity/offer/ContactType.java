package br.com.senior.tradeit.entity.offer;

public enum ContactType {
    WHATSAPP,
    INSTAGRAM,
    FACEBOOK
}
