package br.com.senior.tradeit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TradeitApplication {

	public static void main(String[] args) {
		SpringApplication.run(TradeitApplication.class, args);
	}
}
