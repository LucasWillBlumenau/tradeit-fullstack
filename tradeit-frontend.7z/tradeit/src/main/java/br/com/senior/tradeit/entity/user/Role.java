package br.com.senior.tradeit.entity.user;

public enum Role {
    ROLE_ADMIN,
    ROLE_COMMON,
}
