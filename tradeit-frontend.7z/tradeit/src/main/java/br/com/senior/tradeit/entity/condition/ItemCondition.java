package br.com.senior.tradeit.entity.condition;

public enum ItemCondition {
    NEW,
    NEARLY,
    USED
}
