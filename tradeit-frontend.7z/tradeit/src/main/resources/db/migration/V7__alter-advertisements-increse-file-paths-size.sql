ALTER TABLE advertisements ALTER COLUMN item_video_url TYPE VARCHAR(120);

ALTER TABLE advertisement_images ALTER COLUMN image_url TYPE VARCHAR(120);
