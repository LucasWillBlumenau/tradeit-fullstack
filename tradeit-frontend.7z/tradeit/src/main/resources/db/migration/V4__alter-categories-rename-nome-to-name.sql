ALTER TABLE categories
    RENAME COLUMN nome TO name;