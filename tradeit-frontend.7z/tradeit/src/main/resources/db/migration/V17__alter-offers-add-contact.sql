ALTER TABLE offers
    ADD COLUMN contact_type VARCHAR(9),
    ADD COLUMN contact_info VARCHAR(90);